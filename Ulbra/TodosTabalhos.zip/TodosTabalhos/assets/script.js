//Exercicios da primeira aula
function exercicio1() {
    var x = prompt("Digite o numero");
    if (x > 10) {
      alert (x + ' É maior que 10');
    }
    if(x < 10){
        alert (x + ' É menor que 10');
    }
    if(x==10){
        alert (x + " É igual a 10");
    }
  }

function exercicio2(){
    var a = prompt('Digite o primeiro numero: ');
    var b = prompt('Digite o segundo numero: ');
    var soma = parseFloat(a) + parseFloat(b);
    alert ('Resultado= ' + soma);
}

function exercicio3(){
    var a = prompt('Digite o primeiro numero: ');
    var b = prompt('Digite o segundo numero: ');
    var escolha = prompt('Escolha o que deseja \n1 - soma, 2 - subtração, 3 - Multiplicação, 4 - Divisão',)
    switch (parseInt(escolha)){
        
        case 1: 
            var resultado = parseFloat(a) + parseFloat(b)
            alert ('Soma= ') + resultado ;
            break;
        case 2: 
            var resultado = parseFloat(a) - parseFloat(b)
            alert ('Subtração= ' + resultado);
            break;
        case 3: 
            var resultado = parseFloat(a) * parseFloat(b)
            alert ('Multiplicação= ' + resultado);
            break;
        case 4:            
            var resultado = parseFloat(a) / parseFloat(b)
            alert('Divisão= ' + resultado)
    }
}

function exercicio4(){
    var nome = prompt('Digite o nome: ');
    var i = parseInt(prompt('Digite quantas vezes...: '));
    var texto= "";
    for(var x=0; x<i; x++){
        texto += nome + "<br>";
    }
    document.getElementById("nome").innerHTML = "Nomes=  " + texto;
}

function exercicio5(){
    var nome=[10];
    var endereco=[10];
    var email=[10];
    var i= 0
    nome[i]= prompt('Digite um nome: ');
    endereco[i]= prompt('Digite o endereço: ');
    email[i]= prompt('Digite o email: ');
    for(var x=0;x<=i;x++)
        document.getElementById('dados').innerHTML = "Nome= " + nome[i] + " Endereço= " + endereco[i] + " Email= " + email[i]
    i++;
}

function exercicio6(){
    var dados = {nome: "", endereco: "", email: ""};
    dados.nome=prompt('Digite o nome: ');
    dados.email=prompt('Digite o email: ');
    dados.endereco=prompt('Digite o endereço: ');
    document.getElementById("objeto").innerHTML = "Nomes=  " + dados.nome + " Endereço= " + dados.endereco + " Email= " + dados.email;
}


//Exercicios da segunda aula

function calcular(oper) {
    var valor1 = document.calcform.valor1.value;
    var valor2 = document.calcform.valor2.value;
 
    if (oper == "somar") {
       var res = parseInt(valor1) + parseInt(valor2);
    } else {
       if (oper == "subtrair") {
          var res = valor1-valor2;
       } else {
          if (oper == "multiplicar") {
             var res = valor1*valor2;
          } else {
             var res = valor1/valor2;
          }
       }
    }
 
    document.calcform.res.value = res;
 }

 function calcularKwh() {
    var valor1 = document.luzform.valor1.value;
    var valor2 = document.luzform.valor2.value;
    
    var result = parseFloat(valor1) * parseFloat(valor2); 
     console.log(result)
    if(result>100 && result<=200){
        result = ((result * 25) / 100) + result
        console.log(result)
    }else{

        if(result>200){
            result = ((result * 50) / 100) + result
            console.log(result)
        }
    }

    document.getElementById("result").innerHTML = "Total R$" + result
  }

  function verificarNumeros() {
     var numeros = document.getElementById('maiorNumero').value
     numeros = numeros.split(',')
     var maior = 0
     var i
     for (i = 0 ; i < numeros.length; i++) {
        if (maior < numeros[i]) {
           maior = numeros[i]
        }
     }
     document.getElementById("resultMaiorNumero").innerHTML = "Maior numero = " + maior
  }

  function verificarIdades() {
   var idades = document.getElementById('idades').value
   idades = idades.split(',')
   var idadeMaior = 0
   var idadeMenor = 0
   console.log(idades[0])
   var i
   for (i = 0 ; i < idades.length; i++) {
      if (idades[i]>=18) {
         idadeMaior++
      }else{
         idadeMenor++
      }
   }
   document.getElementById("resultIdades").innerHTML = "Idades maiores de 18 = " + idadeMaior + " Idades menores de 18 = " + idadeMenor
}

//Exerc IMC

function imc() {
    var nome = document.getElementById('nome').value
    var sexo = document.getElementById('sexo').value
    var peso = document.getElementById('peso').value
    var altura = document.getElementById('altura').value

    if (nome != "" && sexo != "" && peso!= "" && altura !="") {
        var imc = parseFloat(peso) / (parseFloat(altura) * parseFloat(altura))
        var imcText
        if (imc<18.5) {
            imcText = "abaixo do peso"
        }
        if (imc>=18.5 || imc==25) {
            imcText = "no peso ideal"
        }
        if (imc>25 || imc==30) {
            imcText = "acima do peso ideal"
        }
        if (imc>30) {
            imcText = "obeso"
        }
        var res = ""+nome+" seu IMC é de: "+ imc+
        " e ele está " + imcText

        document.getElementById("result_IMC").innerHTML = res
    }else{
    alert("Preencha todos os campos.")
    }

}